/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
check = Package.check.check;
Match = Package.check.Match;
Email = Package.email.Email;
EmailInternals = Package.email.EmailInternals;
Counts = Package['tmeasday:publish-counts'].Counts;
publishCount = Package['tmeasday:publish-counts'].publishCount;
SEnum = Package['zeroasterisk:s-enum'].SEnum;
Papa = Package['harrison:papa-parse'].Papa;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Accounts = Package['accounts-base'].Accounts;
Collection2 = Package['aldeed:collection2-core'].Collection2;
Autoupdate = Package.autoupdate.Autoupdate;
SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
MongoObject = Package['aldeed:simple-schema'].MongoObject;

