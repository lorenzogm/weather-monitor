(function(){Meteor.publish('users', function () {
    return Meteor.users.find({}, {
        fields: {
            emails: 1,
            profile: 1
        }
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9hdXRoL3NlcnZlci91c2Vycy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxZQUFXO0FBQy9CLFdBQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFO0FBQ3pCLGNBQU0sRUFBRTtBQUNKLGtCQUFNLEVBQUUsQ0FBQztBQUNULG1CQUFPLEVBQUUsQ0FBQztTQUNiO0tBQ0osQ0FBQyxDQUFDO0NBQ04sQ0FBQyxDQUFDIiwiZmlsZSI6Ii9hdXRoL3NlcnZlci91c2Vycy5qcyIsInNvdXJjZXNDb250ZW50IjpbIk1ldGVvci5wdWJsaXNoKCd1c2VycycsIGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7fSwge1xuICAgICAgICBmaWVsZHM6IHtcbiAgICAgICAgICAgIGVtYWlsczogMSxcbiAgICAgICAgICAgIHByb2ZpbGU6IDFcbiAgICAgICAgfVxuICAgIH0pO1xufSk7XG4iXX0=
}).call(this);
